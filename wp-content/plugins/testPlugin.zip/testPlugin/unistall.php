<?php 


// Si no esta definido la funcion wp unistall, termina la funcion.
if(!defined('WP_UNISTALL_PLUGIN')){
    die();
}

//